using System;
using System.Collections;

using Sooda;

[assembly: SoodaStubAssembly(typeof(VideoRental._DatabaseSchema))]

namespace VideoRental
{
    using VideoRental.TypedQueries;

    class Program
    {
        private static void DumpVideos(VideoList list)
        {
            int count = 0;

            foreach (Video v in list)
            {
                Console.WriteLine(" {0}. \"{1}\" Year: {2}",
                    ++count,
                    v.Title, 
                    v.YearOfProduction);
                Console.WriteLine("    Directed by: {0} Status: '{1}' Category: '{2}'",
                    v.DirectedBy.Name, v.Status.Name, v.Category.Name);
            }
            if (list.Count == 0)
                Console.WriteLine("No videos.");
        }

        #region Sample01: List all videos

        static void Sample01_ListVideos()
        {
            Console.WriteLine();
            Console.WriteLine("All videos:");
            using (SoodaTransaction t = new SoodaTransaction())
            {
                VideoList list;

                list = Video.GetList(true);
                DumpVideos(list);
            }

            // SQL: select * from Video;
        }
        #endregion

        #region Sample02: List videos produced after year 2000
        static void Sample02_ListVideosProducedAfterY2K()
        {
            Console.WriteLine();
            Console.WriteLine("Videos produced after year 2000");
            using (SoodaTransaction t = new SoodaTransaction())
            {
                VideoList list;

                list = Video.GetList(
                    VideoField.YearOfProduction >= 2000);
                DumpVideos(list);
            }
            // SQL: select * from Video where year_of_production >= 2000;
        }
        #endregion

        #region Sample03: More complex query
        static void Sample03_MoreComplexQuery()
        {
            Console.WriteLine();
            Console.WriteLine("More complex query");
            using (SoodaTransaction t = new SoodaTransaction())
            {
                VideoList list;

                list = Video.GetList(
                    VideoField.YearOfProduction >= 2000
                    && VideoField.YearOfProduction <= 2004
                    && VideoField.Status == VideoStatus.RentedOut
                    && VideoField.RentedOutTo.Email.Like("%@customer.com")
                    && VideoField.DirectedBy.Name.Like("Chris%")
                    && VideoField.History.Count > 1
                    //, SoodaSnapshotOptions.PrefetchRelated
                    );
                DumpVideos(list);
            }
        }
        #endregion

        #region Sample04: Collections
        static void Sample04_Collections()
        {
            Console.WriteLine();
            Console.WriteLine("Movies with Emma Watson");
            using (SoodaTransaction t = new SoodaTransaction())
            {
                // look up Emma Watson
                Artist emmaWatson = Artist.LoadSingleObject(ArtistField.Name == "Emma Watson");

                DumpVideos(Video.GetList(
                    VideoField.Actors.Contains(emmaWatson)));
            }
            // SQL: 
            // select * from Video
            // where exists (
            //      select * from Actor2Video 
            //      where video_id=obj.Id and actor_id = 6)
        }
        #endregion

        #region Sample05: Create objects
        static void Sample05_CreateObjects()
        {
            Console.WriteLine();
            using (SoodaTransaction t = new SoodaTransaction())
            {
                // look up Emma Watson
                Artist emmaWatson = Artist.LoadSingleObject(ArtistField.Name == "Emma Watson");

                // Add Emma Watson to all 'Harry Potter' movies

                foreach (Video v in Video.GetList(
                    VideoField.Title.Like("Harry Potter%")))
                {
                    Console.WriteLine("Adding Emma Watson to {0}", v.Title);
                    v.Actors.Add(emmaWatson);
                }

                // no commit yet, but the data can be already queried

                Console.WriteLine("Movies with Emma Watson, after temporarily adding them in uncommitted transaction.");

                // look up Emma Watson

                DumpVideos(Video.GetList(
                    VideoField.Actors.Contains(emmaWatson)));

                // Console.WriteLine(t.Serialize());
                t.Commit();
            }
        }
        #endregion

        #region Sample06: Remove Objects From Collection
        static void Sample06_RemoveObjectsFromCollection()
        {
            Console.WriteLine();
            Console.WriteLine("Movies with Emma Watson");
            using (SoodaTransaction t = new SoodaTransaction())
            {
                // look up Emma Watson
                Artist emmaWatson = Artist.LoadSingleObject(
                    ArtistField.Name == "Emma Watson");

                // Add Emma Watson to all 'Harry Potter' movies
                foreach (Video v in Video.GetList(
                    VideoField.Title.Like("Harry Potter%")))
                {
                    v.Actors.Remove(emmaWatson);
                }
                t.Commit();
            }
        }
        #endregion

        #region Sample07: Inheritance
        static void Sample07_Inheritance()
        {
            Console.WriteLine();
            Console.WriteLine("Polymorphic list of persons:");
            using (SoodaTransaction t = new SoodaTransaction())
            {
                foreach (Person p in Person.GetList(true))
                {
                    Console.WriteLine("    name=\"{0}\" type={1}", p.Name, p.GetType().FullName);
                    p.WriteDetails();
                }
            }
        }
        #endregion

        #region Sample08: Complex update with serialization
        static void Sample08_ComplexUpdateWithSerialization()
        {
            string serialized;

            using (SoodaTransaction t = new SoodaTransaction())
            {
                //
                // new customer wants to rent a movie
                // we do it all in a single transaction
                //

                Customer c = new Customer();
                c.Name = "New Customer";
                c.Email = "new@customer.com";
                c.Address = "Address 1";

                Video v = Video.LoadSingleObject(
                    VideoField.Title == "Die Hard");
                if (v.Status == VideoStatus.RentedOut)
                {
                    v.Return();
                }
                v.RentOut(c);

                // serialize the transaction to XML

                serialized = t.Serialize();
            }

            // the XML can now be moved to another thread or
            // process or machine

            Console.WriteLine("serialized:\n{0}", serialized);

            using (SoodaTransaction t = new SoodaTransaction())
            {
                // deserialize the XML in a new transaction 
                // and commit

                t.Deserialize(serialized);
                t.Commit();
            }

            // cleanup: delete the newly created customer and
            // return all of his videos (if any)
            //
            // returning is done in Customer.BeforeObjectDelete()
            // trigger

            using (SoodaTransaction t = new SoodaTransaction())
            {
                foreach (Customer c in Customer.GetList(
                    CustomerField.Name == "New Customer"))
                {
                    c.MarkForDelete();
                }
                Console.WriteLine("cleanup transaction:\n{0}", t.Serialize());
                t.Commit();
            }
        }
        #endregion

        [STAThread]
        static void Main()
        {
            Sample01_ListVideos();
            Sample02_ListVideosProducedAfterY2K();
            Sample03_MoreComplexQuery();
            Sample04_Collections();
            Sample05_CreateObjects();
            Sample06_RemoveObjectsFromCollection();
            Sample07_Inheritance();
            Sample08_ComplexUpdateWithSerialization();
        }
    }
}
