create table dbo.Actor2Video (
	actor_id int not null,
	video_id int not null,
)
go

create table dbo.Artist (
	id int not null,
	name varchar(64) not null,
)
go

create table dbo.Customer (
	id int not null,
	email varchar(50) not null,
	address varchar(50) not null,
)
go

create table dbo.Employee (
	id int not null,
	login varchar(50) not null,
)
go

create table dbo.KeyGen (
	key_name varchar(64) not null,
	key_value int not null,
)
go

create table dbo.Person (
	id int not null,
	type int not null,
	name varchar(50) not null,
)
go

create table dbo.Video (
	id int not null,
	title nvarchar(50) not null,
	category int not null,
	picture binary null,
	rented_out_to int null,
	rented_date datetime null,
	returned_date datetime null,
	status int not null,
	director int not null,
	year_of_production int not null,
)
go

create table dbo.VideoCategory (
	id int not null,
	name varchar(50) not null,
)
go

create table dbo.VideoHistory (
	id int not null,
	video_id int not null,
	person_id int not null,
	time_stamp datetime not null,
	action_type int not null,
	comment varchar(50) null,
)
go

create table dbo.VideoHistoryActionType (
	id int not null,
	name varchar(50) not null,
)
go

create table dbo.VideoStatus (
	id int not null,
	name varchar(50) not null,
)
go

go
---
--- primary keys
---

alter table dbo.Actor2Video add primary key (actor_id, video_id);
alter table dbo.Artist add primary key (id);
alter table dbo.Customer add primary key (id);
alter table dbo.Employee add primary key (id);
alter table dbo.KeyGen add primary key (key_name);
alter table dbo.Person add primary key (id);
alter table dbo.Video add primary key (id);
alter table dbo.VideoCategory add primary key (id);
alter table dbo.VideoHistory add primary key (id);
alter table dbo.VideoHistoryActionType add primary key (id);
alter table dbo.VideoStatus add primary key (id);
go

---
--- table data
---

---
--- table Actor2Video
---
insert into Actor2Video(actor_id,video_id) values(2,8);
insert into Actor2Video(actor_id,video_id) values(3,8);
go
---
--- table Artist
---
insert into Artist(id,name) values(1,'Chuck Norris');
insert into Artist(id,name) values(2,'Val Kilmer');
insert into Artist(id,name) values(3,'Omar Sharif');
insert into Artist(id,name) values(4,'Daniel Radcliffe');
insert into Artist(id,name) values(5,'Rupert Grint');
insert into Artist(id,name) values(6,'Emma Watson');
insert into Artist(id,name) values(7,'Ralph Fiennes');
insert into Artist(id,name) values(8,'Alan Rickman');
insert into Artist(id,name) values(9,'Jeremy Irons');
insert into Artist(id,name) values(10,'Samuel L. Jackson');
insert into Artist(id,name) values(11,'Bruce Willis');
insert into Artist(id,name) values(12,'John McTiernan');
insert into Artist(id,name) values(13,'Renny Harlin');
insert into Artist(id,name) values(14,'Jerry Zucker');
insert into Artist(id,name) values(15,'Chris Columbus');
insert into Artist(id,name) values(16,'Alfonso Cuar�n');
insert into Artist(id,name) values(17,'Mike Newell');
go
---
--- table Customer
---
insert into Customer(id,email,address) values(3,'caroline@customer.com','4th Street');
insert into Customer(id,email,address) values(4,'mark@customer.com','1st Street');
insert into Customer(id,email,address) values(5,'anna@customer.com','2nd Street');
insert into Customer(id,email,address) values(6,'david@customer.com','3rd Street');
go
---
--- table Employee
---
insert into Employee(id,login) values(1,'edek');
insert into Employee(id,login) values(2,'adminek');
go
---
--- table KeyGen
---
insert into KeyGen(key_name,key_value) values('Person',1031);
insert into KeyGen(key_name,key_value) values('Video',31);
insert into KeyGen(key_name,key_value) values('VideoHistory',1201);
go
---
--- table Person
---
insert into Person(id,type,name) values(1,1,'Edward Employee');
insert into Person(id,type,name) values(2,1,'Andrew Administrator');
insert into Person(id,type,name) values(3,2,'Caroline Customer');
insert into Person(id,type,name) values(4,2,'Mark Customer');
insert into Person(id,type,name) values(5,2,'Anna Customer');
insert into Person(id,type,name) values(6,2,'David Customer');
go
---
--- table Video
---
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(1,'Die Hard',3,null,null,'20060323 14:08:35','20060323 14:08:35',2,12,1988);
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(2,'Die Hard 2: Die Harder',3,null,null,'20060312 00:00:00',null,3,13,1990);
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(3,'Die Hard: With a Vengeance',3,null,null,'20060312 00:00:00','20060315 00:00:00',4,12,1995);
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(4,'Harry Potter and the Philosopher''s Stone',5,null,null,null,null,2,15,2001);
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(5,'Harry Potter and the Chamber of Secrets',5,null,3,'20060321 08:44:38',null,1,15,2002);
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(6,'Harry Potter and the Prisoner of Azkaban',5,null,null,null,null,2,16,2004);
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(7,'Harry Potter and the Goblet of Fire',5,null,null,null,null,2,17,2005);
insert into Video(id,title,category,picture,rented_out_to,rented_date,returned_date,status,director,year_of_production) values(8,'Top Secret',4,null,null,null,null,2,14,1984);
go
---
--- table VideoCategory
---
insert into VideoCategory(id,name) values(1,'Drama');
insert into VideoCategory(id,name) values(2,'Science Fiction');
insert into VideoCategory(id,name) values(3,'Action');
insert into VideoCategory(id,name) values(4,'Comedy');
insert into VideoCategory(id,name) values(5,'Adventure');
go
---
--- table VideoHistory
---
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(41,5,1,'20060320 23:51:49',2,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(51,5,1,'20060320 23:52:35',1,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(61,5,1,'20060320 23:52:40',2,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(71,5,1,'20060320 23:53:04',1,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(81,5,2,'20060320 23:53:35',2,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(91,5,2,'20060320 23:53:43',1,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(101,5,2,'20060320 23:55:10',2,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(111,5,2,'20060321 08:42:44',1,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(121,5,2,'20060321 08:42:57',2,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(131,5,2,'20060321 08:43:09',1,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(141,5,2,'20060321 08:43:16',2,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(151,5,2,'20060321 08:43:48',1,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(161,5,2,'20060321 08:44:29',2,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(171,5,2,'20060321 08:44:38',1,null);
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(231,1,2,'20060321 21:35:23',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(241,1,2,'20060321 21:36:14',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(251,1,2,'20060321 21:36:38',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(261,1,2,'20060321 21:38:23',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(271,1,2,'20060321 21:38:35',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(281,1,2,'20060321 21:39:03',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(291,1,2,'20060321 21:40:57',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(301,1,2,'20060321 21:41:37',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(311,1,2,'20060321 21:42:06',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(321,1,2,'20060321 21:43:26',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(331,1,2,'20060321 21:50:26',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(341,1,2,'20060321 21:50:37',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(342,1,2,'20060321 21:50:38',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(351,1,2,'20060321 21:51:07',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(352,1,2,'20060321 21:51:07',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(361,1,2,'20060321 21:51:53',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(362,1,2,'20060321 21:51:53',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(371,1,2,'20060321 21:58:47',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(372,1,2,'20060321 21:58:47',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(381,1,2,'20060321 21:59:13',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(382,1,2,'20060321 21:59:13',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(391,1,2,'20060321 21:59:37',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(392,1,2,'20060321 21:59:37',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(401,1,2,'20060321 21:59:48',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(402,1,2,'20060321 21:59:48',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(411,1,2,'20060321 22:00:09',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(412,1,2,'20060321 22:00:09',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(421,1,2,'20060321 22:00:29',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(431,1,2,'20060321 22:00:55',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(441,1,2,'20060321 22:01:01',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(451,1,2,'20060321 22:04:04',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(461,1,2,'20060321 22:04:37',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(462,1,2,'20060321 22:04:37',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(471,1,2,'20060321 22:04:51',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(472,1,2,'20060321 22:04:51',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(481,1,2,'20060321 22:05:08',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(482,1,2,'20060321 22:05:08',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(491,1,2,'20060321 22:08:08',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(492,1,2,'20060321 22:08:08',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(501,1,2,'20060321 22:08:44',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(502,1,2,'20060321 22:08:44',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(511,1,2,'20060321 22:08:54',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(512,1,2,'20060321 22:08:54',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(521,1,2,'20060321 22:10:19',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(522,1,2,'20060321 22:10:19',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(531,1,2,'20060321 22:10:32',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(532,1,2,'20060321 22:10:32',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(541,1,2,'20060321 22:11:05',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(542,1,2,'20060321 22:11:05',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(551,1,2,'20060321 22:11:11',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(552,1,2,'20060321 22:11:12',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(561,1,2,'20060321 22:11:28',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(562,1,2,'20060321 22:11:28',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(571,1,2,'20060321 22:11:58',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(572,1,2,'20060321 22:11:58',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(581,1,2,'20060321 22:12:41',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(582,1,2,'20060321 22:12:41',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(591,1,2,'20060321 22:12:57',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(592,1,2,'20060321 22:12:57',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(601,1,2,'20060321 22:13:01',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(602,1,2,'20060321 22:13:01',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(611,1,2,'20060321 22:15:06',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(612,1,2,'20060321 22:15:06',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(621,1,2,'20060321 22:15:27',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(622,1,2,'20060321 22:15:27',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(631,1,2,'20060321 22:16:04',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(632,1,2,'20060321 22:16:04',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(641,1,2,'20060321 22:16:48',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(642,1,2,'20060321 22:16:48',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(651,1,2,'20060321 22:18:30',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(652,1,2,'20060321 22:18:30',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(661,1,2,'20060322 09:56:47',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(662,1,2,'20060322 09:57:53',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(671,1,2,'20060322 09:58:47',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(672,1,2,'20060322 09:58:48',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(681,1,2,'20060322 09:58:55',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(682,1,2,'20060322 09:58:55',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(691,1,2,'20060322 10:05:21',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(692,1,2,'20060322 10:05:22',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(701,1,2,'20060322 10:20:43',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(702,1,2,'20060322 10:20:44',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(711,1,2,'20060322 10:21:46',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(712,1,2,'20060322 10:21:47',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(721,1,2,'20060322 10:25:52',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(722,1,2,'20060322 10:25:52',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(731,1,2,'20060322 10:27:50',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(732,1,2,'20060322 10:27:50',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(741,1,2,'20060322 10:29:26',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(742,1,2,'20060322 10:29:26',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(761,1,2,'20060322 10:31:08',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(762,1,2,'20060322 10:31:08',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(771,1,2,'20060322 10:31:31',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(772,1,2,'20060322 10:31:31',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(781,1,2,'20060322 10:34:23',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(782,1,2,'20060322 10:34:23',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(791,1,2,'20060322 10:34:44',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(792,1,2,'20060322 10:34:52',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(801,1,2,'20060322 10:34:56',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(802,1,2,'20060322 10:34:57',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(821,1,2,'20060322 10:35:07',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(822,1,2,'20060322 10:35:07',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(831,1,2,'20060322 10:35:57',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(832,1,2,'20060322 10:36:00',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(851,1,2,'20060322 10:36:35',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(852,1,2,'20060322 10:36:38',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(861,1,2,'20060322 10:36:42',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(862,1,2,'20060322 10:36:43',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(871,1,2,'20060322 10:36:55',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(872,1,2,'20060322 10:37:06',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(881,1,2,'20060322 10:38:30',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(882,1,2,'20060322 10:38:32',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(891,1,2,'20060322 10:40:12',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(892,1,2,'20060322 10:40:12',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(901,1,2,'20060322 10:40:53',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(902,1,2,'20060322 10:40:53',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(911,1,2,'20060322 10:42:14',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(912,1,2,'20060322 10:42:14',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(921,1,2,'20060322 10:42:27',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(922,1,2,'20060322 10:42:27',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(931,1,2,'20060322 10:47:43',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(932,1,2,'20060322 10:47:43',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(941,1,2,'20060322 10:47:50',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(942,1,2,'20060322 10:47:50',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(951,1,2,'20060323 11:39:33',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(952,1,2,'20060323 11:39:33',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(961,1,2,'20060323 11:41:48',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(962,1,2,'20060323 11:41:48',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(971,1,2,'20060323 13:19:44',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(972,1,2,'20060323 13:19:45',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(981,1,2,'20060323 13:19:54',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(982,1,2,'20060323 13:19:55',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(991,1,2,'20060323 13:29:25',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(992,1,2,'20060323 13:29:25',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1001,1,2,'20060323 13:31:13',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1002,1,2,'20060323 13:31:14',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1011,1,2,'20060323 13:45:29',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1012,1,2,'20060323 13:45:29',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1021,1,2,'20060323 13:45:52',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1022,1,2,'20060323 13:45:52',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1031,1,2,'20060323 13:46:12',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1032,1,2,'20060323 13:46:12',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1041,1,2,'20060323 13:46:27',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1042,1,2,'20060323 13:46:27',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1051,1,2,'20060323 13:46:53',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1052,1,2,'20060323 13:46:53',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1061,1,2,'20060323 13:47:18',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1062,1,2,'20060323 13:47:18',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1071,1,2,'20060323 13:47:48',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1072,1,2,'20060323 13:47:48',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1081,1,2,'20060323 13:47:59',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1082,1,2,'20060323 13:47:59',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1091,1,2,'20060323 13:48:06',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1092,1,2,'20060323 13:48:06',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1101,1,2,'20060323 13:49:01',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1102,1,2,'20060323 13:49:01',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1111,1,2,'20060323 13:49:09',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1112,1,2,'20060323 13:49:10',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1121,1,2,'20060323 13:49:45',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1122,1,2,'20060323 13:49:45',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1131,1,2,'20060323 13:51:17',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1132,1,2,'20060323 13:51:17',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1141,1,2,'20060323 13:51:34',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1142,1,2,'20060323 13:51:35',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1151,1,2,'20060323 13:52:31',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1152,1,2,'20060323 13:52:31',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1161,1,2,'20060323 13:52:43',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1162,1,2,'20060323 13:52:44',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1171,1,2,'20060323 13:52:57',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1172,1,2,'20060323 13:52:58',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1181,1,2,'20060323 14:07:50',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1182,1,2,'20060323 14:07:50',2,'Video has been returned in good condition');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1191,1,2,'20060323 14:08:35',1,'Video has been rented out');
insert into VideoHistory(id,video_id,person_id,time_stamp,action_type,comment) values(1192,1,2,'20060323 14:08:35',2,'Video has been returned in good condition');
go
---
--- table VideoHistoryActionType
---
insert into VideoHistoryActionType(id,name) values(1,'Rented Out');
insert into VideoHistoryActionType(id,name) values(2,'Returned');
insert into VideoHistoryActionType(id,name) values(3,'Reported Loss');
insert into VideoHistoryActionType(id,name) values(4,'Reported Damaged');
insert into VideoHistoryActionType(id,name) values(5,'Created');
insert into VideoHistoryActionType(id,name) values(6,'Deactivated');
go
---
--- table VideoStatus
---
insert into VideoStatus(id,name) values(1,'Rented Out');
insert into VideoStatus(id,name) values(2,'Available');
insert into VideoStatus(id,name) values(3,'Damaged');
insert into VideoStatus(id,name) values(4,'Lost');
go
go

---
--- indexes
---

go
---
--- triggers
---

go
---
--- constraints
---

alter table dbo.Actor2Video add constraint FK_Actor2Video_Actor foreign key (actor_id) references dbo.Artist(id);
alter table dbo.Actor2Video add constraint FK_Actor2Video_Video foreign key (video_id) references dbo.Video(id);
alter table dbo.Customer add constraint FK_Customer_Person foreign key (id) references dbo.Person(id);
alter table dbo.Employee add constraint FK_Employee_Person foreign key (id) references dbo.Person(id);
alter table dbo.Video add constraint FK_Video_Customer foreign key (rented_out_to) references dbo.Customer(id);
alter table dbo.Video add constraint FK_Video_Performer foreign key (director) references dbo.Artist(id);
alter table dbo.Video add constraint FK_Video_VideoCategory foreign key (category) references dbo.VideoCategory(id);
alter table dbo.Video add constraint FK_Video_VideoStatus foreign key (status) references dbo.VideoStatus(id);
alter table dbo.VideoHistory add constraint FK_VideoHistory_Person foreign key (person_id) references dbo.Person(id);
alter table dbo.VideoHistory add constraint FK_VideoHistory_Video foreign key (video_id) references dbo.Video(id);
alter table dbo.VideoHistory add constraint FK_VideoHistory_VideoHistoryActionType foreign key (action_type) references dbo.VideoHistoryActionType(id);
go
go
go
---
--- permissions
---

go
